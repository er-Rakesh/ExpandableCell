//
//  ExpandableVC.swift
//  Expandable TableView
//
//  Created by Rakesh Kumawat on 7/31/20.
//  Copyright © 2020 Rakesh Kumawat. All rights reserved.
//

import UIKit

class ExpandableVC: UIViewController {

    @IBOutlet weak var tableSetting: UITableView!
       
       var arrayHeader = [1, 1, 1, 1] // 2 Array of header, change it as per your uses
        //  var arrayItem = [11,12,13,14]
           override func viewDidLoad() {
               super.viewDidLoad()
               // Do any additional setup after loading the view, typically from a nib.
               tableSetting.dataSource = self
               tableSetting.delegate = self
               tableSetting.tableFooterView = UIView()
           }
       }

       extension ExpandableVC: UITableViewDataSource, UITableViewDelegate {
           
           func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
               return 40
             //  return UITableView.automaticDimension
           }
           
           // 4
           func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
               let viewHeader = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 40))
            //   viewHeader.backgroundColor = UIColor.darkGray // Changing the header background color to gray
               viewHeader.backgroundColor = UIColor.blue
               
               let button = UIButton(type: .custom)
                      button.frame = viewHeader.bounds
                      button.tag = section // Assign section tag to this button
                      button.addTarget(self, action: #selector(tapSection(sender:)), for: .touchUpInside)
                     // button.setTitle("Section: \(section)", for: .normal)
                    button.setTitle("Header: \(section)", for: .normal)
                      viewHeader.addSubview(button)
           
               return viewHeader
           }
           
           // 5
           func numberOfSections(in tableView: UITableView) -> Int {
               return arrayHeader.count
              // return 1

           }
           
           func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
               // 6 Change the number of row in section as per your uses
               // return 4
               return (self.arrayHeader[section] == 0) ? 0 : 2

           }
           
           // 7
           func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
               let cell = tableView.dequeueReusableCell(withIdentifier: "ExpandCell", for: indexPath)
             //  cell.textLabel?.text = "section: \(indexPath.section)  row: \(indexPath.row)"
               cell.textLabel?.text = "Cell"
               cell.textLabel?.text = "Meenal".uppercased()
               cell.imageView?.image = UIImage(named: "image")
               cell.selectionStyle = .none
               
               return cell
           }
           
           @objc func tapSection(sender: UIButton) {
                 self.arrayHeader[sender.tag] = (self.arrayHeader[sender.tag] == 0) ? 1 : 0
                 self.tableSetting.reloadSections([sender.tag], with: .fade)
             }
    
}
